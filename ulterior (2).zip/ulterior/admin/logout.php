<!-- "General Solutions"
**********************************************
* Developer    : mas Ti solutions
* Company      : mas Ti
* Release Date : 1 Junio 2021
* Website      : www.ulterior.com.mx
* E-mail       : cercoth@gmail.com
* Phone        : +52 33.1739.2748
-->

<?php
session_start();
// delete session
session_destroy();

// switch to login page (index.php) and give alert = 2
header('Location: index.php?alert=2');
?>