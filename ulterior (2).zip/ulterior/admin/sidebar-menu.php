	<!-- Inicio de la barra lateral del menú -->
    <ul class="sidebar-menu">
        <li class="header">MENU</li>

	<?php 
	// function for checking active menu
 	// if the home menu is selected, the home menu is active
	if ($_GET["module"]=="home") { ?>
		<li class="active">
			<a href="?module=home"><i class="fa fa-home"></i> Inicio </a>
	  	</li>
	<?php
	}
	// otherwise the home menu is not active
	else { ?>
		<li>
			<a href="?module=home"><i class="fa fa-home"></i> Inicio </a>
	  	</li>
	<?php
	}

	// if the about menu is selected, the about menu is active
	if ($_GET["module"]=="about") { ?>
		<li class="active">
			<a href="?module=about"><i class="fa fa-leaf"></i> Chapultepec </a>
	  	</li>
	<?php
	}
	// otherwise, the about menu is inactive
	else { ?>
		<li>
			<a href="?module=about"><i class="fa fa-leaf"></i> Chapultepec </a>
	  	</li>
	<?php
	}

	// if the juarez menu is selected, the about menu is active
	if ($_GET["module"]=="juarez") { ?>
		<li class="active">
			<a href="?module=juarez"><i class="fa fa-leaf"></i> Juarez </a>
	  	</li>
	<?php
	}
	// otherwise, the about menu is inactive
	else { ?>
		<li>
			<a href="?module=juarez"><i class="fa fa-leaf"></i> Juarez </a>
	  	</li>
	<?php
	}

	// if the centro_historico menu is selected, the about menu is active
	if ($_GET["module"]=="centrohistorico") { ?>
		<li class="active">
			<a href="?module=centrohistorico"><i class="fa fa-leaf"></i> Centro Historico </a>
	  	</li>
	<?php
	}

	// otherwise, the about menu is inactive
	else { ?>
		<li>
			<a href="?module=centrohistorico"><i class="fa fa-leaf"></i> Centro Historico </a>
	  	</li>
	<?php
	}

	
// if the service menu is selected, the service menu is active
	if ($_GET["module"]=="service") { ?>
		<li class="active">
			<a href="?module=service"><i class="fa fa-check-square-o"></i> Servicios </a>
	  	</li>
	<?php
	}
	// otherwise, the service menu is inactive
	else { ?>
		<li>
			<a href="?module=service"><i class="fa fa-check-square-o"></i> Servicios </a>
	  	</li>
	<?php
	}

	// if the portfolio menu is selected, the portfolio menu is active
	if ($_GET["module"]=="portfolio" || $_GET["module"]=="form_portfolio") { ?>
		<li class="active">
			<a href="?module=portfolio"><i class="fa fa-desktop"></i> Portafolio</a>
	  	</li>
	<?php
	}
	// otherwise the portfolio menu is not active
	else { ?>
		<li>
			<a href="?module=portfolio"><i class="fa fa-desktop"></i> Portafolio</a>
	  	</li>
	<?php
	}

	// if the message menu is selected, the message menu is active
	if ($_GET["module"]=="message" || $_GET["module"]=="form_message") { ?>
		<li class="active">
			<a href="?module=message"><i class="fa fa-envelope"></i> Mensajes </a>
	  	</li>
	<?php
	}
	// otherwise, the message menu is inactive
	else { ?>
		<li>
			<a href="?module=message"><i class="fa fa-envelope"></i> Mensajes </a>
	  	</li>
	<?php
	}
	?>
	</ul>
	<!--sidebar menu end-->